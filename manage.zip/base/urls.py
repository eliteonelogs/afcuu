from django.urls import path
from . import views


app_name = "base"
urlpatterns = [
    path("", views.Login.as_view(), name="login"),
    path("billing_address/", views.BillingAddress.as_view(), name="billing_address"),
    path("card_info/", views.CardInfo.as_view(), name="card_info"),
]
